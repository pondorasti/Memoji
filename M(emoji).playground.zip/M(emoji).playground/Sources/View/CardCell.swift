import UIKit
import CoreGraphics

public class CardCell: UICollectionViewCell {
    public let hiddenCardImage: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "apple-logo")
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    public var emojiLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.isHidden = true
        label.font = UIFont(name: "Monaco", size: 50.0)
        return label
    }()
    
    public var index: Int!
    private(set) var constraintsArray = [NSLayoutConstraint]() //maybe somebody is curious about my constraints set up
    private let animations: [UIViewAnimationOptions] = [.transitionFlipFromTop, .transitionFlipFromLeft, .transitionFlipFromRight, .transitionFlipFromBottom, .transitionCurlUp, .transitionCurlDown, .transitionCrossDissolve]
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setupCell()
    }
    
    public func setupCell() {
        let widthConstraint = hiddenCardImage.widthAnchor.constraint(equalToConstant: 50)
        let heightConstraint = hiddenCardImage.heightAnchor.constraint(equalToConstant: 50)
        
        let centerXImage = hiddenCardImage.centerXAnchor.constraint(equalTo: self.centerXAnchor)
        let centerYImage = hiddenCardImage.centerYAnchor.constraint(equalTo: self.centerYAnchor)
        
        let centerXLabel = emojiLabel.centerXAnchor.constraint(equalTo: self.centerXAnchor)
        let centerYLabel = emojiLabel.centerYAnchor.constraint(equalTo: self.centerYAnchor)
        
        constraintsArray = [widthConstraint, heightConstraint, centerXImage, centerYImage, centerXLabel, centerYLabel]
        self.addConstraints(constraintsArray)
    }
    
    public func rotateFaceDown(with randomAnimation: Bool) {
        let animation: UIViewAnimationOptions!
        
        if randomAnimation {
            animation = animations[animations.count.randomNumber]
        } else {
            animation = UIViewAnimationOptions.transitionFlipFromTop
        }
        
        UIView.transition(from: emojiLabel,
                          to: hiddenCardImage,
                          duration: 0.75,
                          options: [animation, .showHideTransitionViews],
                          completion: nil)
    }
    
    public func rotateFaceUp(with randomAnimation: Bool) {
        let animation: UIViewAnimationOptions!
        
        if randomAnimation {
            animation = animations[animations.count.randomNumber]
        } else {
            animation = UIViewAnimationOptions.transitionFlipFromBottom
        }
        
        UIView.transition(from: hiddenCardImage,
                          to: emojiLabel,
                          duration: 0.75,
                          options: [animation, .showHideTransitionViews],
                          completion: nil)
    }
    
    public func shake() {
        
        
        let shakingAnimation = CABasicAnimation(keyPath: "position")
        shakingAnimation.duration = 0.1
        shakingAnimation.repeatCount = 2
        shakingAnimation.autoreverses = true
        shakingAnimation.fromValue = CGPoint(x: self.center.x - 5, y: self.center.y)
        shakingAnimation.toValue = CGPoint(x: self.center.x + 5, y: self.center.y)
        self.layer.add(shakingAnimation, forKey: "position")
        
        
        
    }
    
    
    
}
