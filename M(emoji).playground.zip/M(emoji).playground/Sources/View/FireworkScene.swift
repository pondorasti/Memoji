import SpriteKit

//This is Under Construction

public class FireworkScene: SKScene {
    private var emitterNode: SKEmitterNode!
    private var background: SKSpriteNode!
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public init(size: CGSize) {
        super.init(size: size)
    }
    
    override public func didMove(to view: SKView) {
        
    }
    
    public func playFireworks() {
        emitterNode = SKEmitterNode(fileNamed: "Firework")
        emitterNode.position = randomPosition()
        emitterNode.targetNode = self
        
        let waitAction = SKAction.wait(forDuration: TimeInterval(emitterNode.particleLifetime))
        let removeAction = SKAction.run { self.emitterNode.removeFromParent() }
        let sequence = SKAction.sequence([waitAction, removeAction])
        emitterNode.run(sequence)
        
        addChild(emitterNode)
    }
    
    private func randomPosition() -> CGPoint {
        guard let scene = self.scene else { return CGPoint(x: 0.5, y: 0.5) }
        //Note: x & y values might be wrong for a good position
        let x = Int(scene.size.width - 300)
        let y = Int(scene.size.height - 300)
        return CGPoint(x: x.randomNumber, y: y.randomNumber)
    }
    
}
