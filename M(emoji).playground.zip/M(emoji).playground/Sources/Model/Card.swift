import Foundation

public struct Card {
    public var isMatched = false
    public var id: Int
    public var numberOfFlips = 0
    
    private static var IDCounter = 0
    private static func createID() -> Int {
        IDCounter += 1
        return IDCounter
    }
    
    init() {
        self.id = Card.createID()
    }
}
