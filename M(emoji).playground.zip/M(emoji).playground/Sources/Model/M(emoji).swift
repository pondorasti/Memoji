import Foundation
import GameplayKit

public class Memoji {
    public var cards = [Card]()
    public var score = 0
    public var highScore = 0
    public var theme = "Winter"
    public var matchedPairs = 0
    
    public init(_ numberOfPairs: Int) {
        for _ in 0 ..< numberOfPairs {
            let card = Card()
            cards += [card, card]
        }
        cards = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: cards) as! [Card]
    }
    
    public func matchingCards(at firstIndex: Int, with secondIndex: Int) -> Bool {
        cards[firstIndex].numberOfFlips += 1
        cards[secondIndex].numberOfFlips += 1
        
        if cards[firstIndex].id == cards[secondIndex].id {
            if cards[firstIndex].numberOfFlips == 1 && cards[secondIndex].numberOfFlips == 1 {
                score += 5
            } else {
                score += 2
            }
            cards[firstIndex].isMatched = true
            cards[secondIndex].isMatched = true
            return true
        } else {
            if cards[firstIndex].numberOfFlips >= 3 || cards[secondIndex].numberOfFlips >= 3 {
                score -= 3
            }
            return false
        }
    }
    
    public func reset() {
        score = 0
        matchedPairs = 0
        cards = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: cards) as! [Card]
        for index in cards.indices {
            cards[index].numberOfFlips = 0
            cards[index].isMatched = false
        }
    }
}
