import Foundation
import UIKit
import SpriteKit
import AVFoundation

public class GameController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    private var cardsCollectionView: UICollectionView!
    private var fireworksView: SKView!
    private var game: Memoji!
    private var onlyFaceUpCell: CardCell?
    public var randomAnimation = false
    
    private var menuButtons = [UIButton]()
    private var switchButton: UIButton!
    private var startButton: UIButton!
    private var buttonsVisible = false
    
    private var matchingCardSounds = [AVAudioPlayer]()
    private var endGameSound: AVAudioPlayer!
    private var notMatchingCardSound: AVAudioPlayer!
    
    public var numberOfPairs = 10
    
    private var emojiChoices = [String]()
    private var chosenEmojis = [Int:String]()
    public var themes = ["Custom": ["⚔️", "🍩", "😍", "🍪", "🎮", "🏅", "🌈", "❤️", "📱", "🚀"],
                         "Winter": ["⛄️", "🎿", "🏂", "🌨", "❄️", "⛷", "🏔", "☃️", "🗻", "🛷"],
                         "Animals": ["🐶", "🐱", "🐭", "🐹", "🦍", "🦖", "🐙", "🦁", "🐳", "🐍"]
    ];
    
    private var scoreLabel: UILabel = {
        let label = UILabel()
        label.frame = CGRect(x: 630, y: 16, width: 133, height: 33)
        label.isHidden = false
        
        label.font = UIFont(name: "Monaco", size: 18.0)
        label.textColor = UIColor.black
        label.textAlignment = .center
        label.text = "Score: 0"
        
        label.layer.backgroundColor = UIColor(red: 242/255, green: 242/255, blue: 242/255, alpha: 0.9).cgColor
        label.layer.cornerRadius = 8.0
        
        label.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        label.layer.shadowRadius = 2.0
        label.layer.shadowOpacity = 0.5
        return label
    }()
    
    private var highScoreLabel: UILabel = {
        let label = UILabel()
        label.frame = CGRect(x: 490, y: 16, width: 133, height: 33)
        label.isHidden = false
        
        label.font = UIFont(name: "Monaco", size: 18.0)
        label.textColor = UIColor.black
        label.textAlignment = .center
        label.text = "Best: ❓"
        
        label.layer.backgroundColor = UIColor(red: 242/255, green: 242/255, blue: 242/255, alpha: 0.9).cgColor
        label.layer.cornerRadius = 8.0
        
        label.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        label.layer.shadowRadius = 2.0
        label.layer.shadowOpacity = 0.5
        return label
    }()
    
    private var score = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
        }
    }
    
    @objc private func startGame(_ sender: UIButton) {
        sender.isUserInteractionEnabled = false
        showCards()
        UIView.animate(withDuration: 0.5, animations: {
            sender.alpha = 0
        })
    }
    
    @objc private func buttonAction(_ sender: UIButton!) {
        if buttonsVisible {
            hideButtons()
        } else {
            showButtons()
        }
    }
    
    @objc private func themeButtons(_ sender: UIButton) {
        if let themeLabelText = sender.titleLabel?.text {
            game.theme = themeLabelText
            resetGame()
        } else {
            showError()
        }
    }
    
    @objc private func reset(_ sender: UIButton) {
        resetGame()
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        game = Memoji(numberOfPairs)
        
        emojiChoices = themes["Winter"]!
        
        view.backgroundColor = UIColor.white
        view.frame = CGRect(x: 0, y: 0, width: 800, height: 600)
        
        //        fireworksView = SKView(frame: view.frame)
        //        let gameScene = FireworkScene(size: CGSize(width: view.frame.width, height: view.frame.height))
        //        gameScene.backgroundColor = .clear
        //        fireworksView.presentScene(gameScene)
        //        view.addSubview(fireworksView)
        
        setupButtons()
        setupCollectionView()
        setupAudioPlayer()
        
        let centerXstartButton = startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        
        view.addConstraints([centerXstartButton])
    }
    
    private func showCards() {
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(800), execute: {
            for index in 0 ..< self.numberOfPairs * 2 {
                guard let cell = self.cardsCollectionView.cellForItem(at: IndexPath(row: index, section: 0)) as? CardCell else { return }
                cell.rotateFaceUp(with: self.randomAnimation)
            }
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(4000), execute: {
            for index in 0 ..< self.numberOfPairs * 2 {
                guard let cell = self.cardsCollectionView.cellForItem(at: IndexPath(row: index, section: 0)) as? CardCell else { return }
                cell.rotateFaceDown(with: self.randomAnimation)
            }
        })
        cardsCollectionView.isUserInteractionEnabled = true
    }
    
    private func resetGame() {
        if game.score > game.highScore && game.matchedPairs == numberOfPairs {
            highScoreLabel.text = "Best: \(game.score)"
            game.highScore = game.score
        }
        score = 0
        
        cardsCollectionView.isUserInteractionEnabled = false
        for index in 0 ..< self.numberOfPairs * 2 {
            guard let cell = self.cardsCollectionView.cellForItem(at: IndexPath(row: index, section: 0)) as? CardCell else { return }
            if cell.isUserInteractionEnabled == false {
                cell.rotateFaceDown(with: self.randomAnimation)
                cell.isUserInteractionEnabled = true
            }
        }
        
        onlyFaceUpCell = nil
        game.reset()
        chosenEmojis.removeAll()
        emojiChoices = themes[game.theme]!
        
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.cardsCollectionView.reloadData()
            self.startButton.isUserInteractionEnabled = true
            UIView.animate(withDuration: 0.5, animations: {
                self.startButton.alpha = 1
            })
        })
    }
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return game.cards.count
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as? CardCell else { return UICollectionViewCell() }
        cell.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.9)
        cell.index = indexPath.row
        
        cell.layer.cornerRadius = 8.0
        cell.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        cell.layer.shadowRadius = 2.0
        cell.layer.shadowOpacity = 0.5
        
        cell.emojiLabel.text = findEmoji(for: cell.index)
        
        cell.addSubview(cell.emojiLabel)
        cell.addSubview(cell.hiddenCardImage)
        
        return cell
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let cell = collectionView.cellForItem(at: indexPath) as? CardCell else { return }
        cell.rotateFaceUp(with: randomAnimation)
        cell.isUserInteractionEnabled = false
        
        //print(game.cards[indexPath.row].id)
        
        if let oldCell = onlyFaceUpCell {
            if game.matchingCards(at: oldCell.index, with: indexPath.row) {
                game.matchedPairs += 1
                if game.matchedPairs == numberOfPairs {
                    showMessage()
                    endGameSound.play()
                } else {
                    DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(750), execute: {
                        self.matchingCardSounds[3.randomNumber].play()
                    })
                }
                print("match")
            } else {
                DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(800), execute: {
                    self.notMatchingCardSound.play()
                    cell.shake()
                    oldCell.shake()
                })
                DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1400), execute: {
                    cell.isUserInteractionEnabled = true
                    cell.rotateFaceDown(with: self.randomAnimation)
                    oldCell.isUserInteractionEnabled = true
                    oldCell.rotateFaceDown(with: self.randomAnimation)
                })
            }
            onlyFaceUpCell = nil
        } else {
            onlyFaceUpCell = cell
        }
        score = game.score
    }
    
    private func findEmoji(for index: Int) -> String {
        if chosenEmojis[game.cards[index].id] == nil {
            chosenEmojis[game.cards[index].id] = emojiChoices.remove(at: emojiChoices.count.randomNumber)
        }
        return chosenEmojis[game.cards[index].id] ?? "🤯"
    }
    
    private func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        
        layout.sectionInset.left = 12.5
        layout.sectionInset.right = 12.5
        layout.sectionInset.bottom = 12.5
        layout.sectionInset.top = 12.5
        
        layout.minimumLineSpacing = 12.5
        layout.itemSize = CGSize(width: 85, height: 85)
        
        cardsCollectionView = UICollectionView(frame: CGRect(x: 135, y: 100, width: 505, height: 600), collectionViewLayout: layout)
        cardsCollectionView.backgroundColor = .clear
        
        cardsCollectionView.delegate = self
        cardsCollectionView.dataSource = self
        cardsCollectionView.register(CardCell.self, forCellWithReuseIdentifier: "cell")
        cardsCollectionView.isUserInteractionEnabled = false
        
        view.addSubview(cardsCollectionView)
    }
    
    private func setupButtons() {
        scoreLabel.layer.cornerRadius = 8.0
        highScoreLabel.layer.cornerRadius = 8.0
        
        switchButton = makeButton(with: "Menu", of: CGRect(x: 7, y: 16, width: 133, height: 33))
        switchButton.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        switchButton.isHidden = false
        
        startButton = makeButton(with: "Start Game", of: CGRect(x: 285, y: 530, width: 189, height: 47))
        startButton.addTarget(self, action: #selector(startGame), for: .touchUpInside)
        startButton.isHidden = false
        
        menuButtons.append(makeButton(with: "Winter", of: CGRect(x: 7, y: 16, width: 133, height: 33)))
        menuButtons.last!.addTarget(self, action: #selector(themeButtons), for: .touchUpInside)
        
        menuButtons.append(makeButton(with: "Animals", of: CGRect(x: 7, y: 16, width: 133, height: 33)))
        menuButtons.last!.addTarget(self, action: #selector(themeButtons), for: .touchUpInside)
        
        menuButtons.append(makeButton(with: "Custom", of: CGRect(x: 7, y: 16, width: 133, height: 33)))
        menuButtons.last!.addTarget(self, action: #selector(themeButtons), for: .touchUpInside)
        
        menuButtons.append(makeButton(with: "Reset", of: CGRect(x: 7, y: 16, width: 133, height: 33)))
        menuButtons.last!.addTarget(self, action: #selector(reset), for: .touchUpInside)
        
        view.addSubview(scoreLabel)
        view.addSubview(highScoreLabel)
        view.addSubview(switchButton)
        view.addSubview(startButton)
        for button in menuButtons {
            view.addSubview(button)
        }
    }
    
    private func setupAudioPlayer() {
        //maybe I could have done all this in only one chunk of do-catch, but I wanted to separate them by good and bad :]
        do {
            let path = Bundle.main.path(forResource: "endClap", ofType: "m4a")
            endGameSound = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
            for index in 0 ... 2 {
                let path = Bundle.main.path(forResource: "Clapping\(index)", ofType: "m4a")
                let sound = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
                matchingCardSounds.append(sound)
            }
        } catch {
            showError()
        }
        
        do {
            let path = Bundle.main.path(forResource: "notMatching", ofType: "m4a")
            notMatchingCardSound = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
        } catch {
            showError()
        }
    }
    
    private func makeButton(with title: String, of size: CGRect) -> UIButton {
        let button = UIButton(type: .system)
        button.frame = size
        button.isHidden = true
        
        button.setTitle(title, for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.titleLabel?.font = UIFont(name: "Monaco", size: 18.0)
        button.titleLabel?.textAlignment = .center
        
        button.layer.backgroundColor = UIColor(red: 242/255, green: 242/255, blue: 242/255, alpha: 0.9).cgColor
        button.layer.cornerRadius = 8.0
        button.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
        button.layer.shadowRadius = 2.0
        button.layer.shadowOpacity = 0.5
        
        return button
    }
    
    private func showButtons() {
        buttonsVisible = true
        for (index, button) in menuButtons.enumerated() {
            button.isHidden = false
            UIView.animate(withDuration: 0.5,
                           delay: 0.05 * Double(index),
                           usingSpringWithDamping: 0.65,
                           initialSpringVelocity: 0.0,
                           options: [], animations: {
                            button.alpha = 1
                            button.frame.origin.y = 60 + CGFloat(index) * (button.frame.size.height + 10)
            })
        }
    }
    
    private func hideButtons() {
        buttonsVisible = false
        for button in menuButtons {
            UIView.animate(withDuration: 0.35, animations: {
                button.frame.origin.y = 16
                button.alpha = 0
            })
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(500), execute: {
            for button in self.menuButtons {
                button.isHidden = true
            }
        })
    }
    
    private func showError() {
        print("There was a problem loading this content")
    }
    
    private func showMessage() {
        let ac = UIAlertController(title: "Congratulations!", message: nil, preferredStyle: .alert)
        ac.message = "Good job! Hope you had fun and may the force be with you :]"
        ac.addAction(UIAlertAction(title: "Ready for another game?", style: .default) { [unowned self, ac] _ in
            self.resetGame()
        })
        present(ac, animated: true)
    }
    
    public func show() {
        print("bum")
    }
}
