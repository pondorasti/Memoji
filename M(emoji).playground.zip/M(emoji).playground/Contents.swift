/*:
 
 # The M(emoji) Project
 
 Created By [Alexandru Turcanu](https://github.com/Pondorasti)
 
 */


import PlaygroundSupport


/*:
 
 ## M(emoji)
 
 Hey WWDC, I've got something to show you...
 
 What's this? How can I play it?
 
 That's M(emoji)! A memory game that uses emojis for the front face of the cards. It's easy don't worry. You just need to match all the cards, for each emoji there's a pair of 2 identical cards. After you get ready press the start button, but...
 
 Oh! What happened all the cards were showed, but I couldn't get glimpse of anything! Now I can't even find the start button!
 
 First things first! Before you do anything you've got to let me finish my talk. I have prepared something for naughty little guys like you, in the upper left corner there's a Menu button, press it. A few more buttons are going to appear, that's the place where you can reset everything, besides the high-score, and change the themes of emoji. Now, after you press the start button you will get a preview of all the cards and then you can start playing. You goal is pretty simple, just focus and match all the cards.
 
 Thanks for the tips! Now it's time to have some fun!
 
 */


var controller = GameController()
PlaygroundPage.current.liveView = controller.view
controller.randomAnimation = true


/*:
 
 ### There's still a few things I need to tell you before I go
 If you want more diversity regarding the animations for flipping the cards try this:
 - example:
 `controller.randomAnimation = true`
 
 You can even personalize the game by adding or removing emojis to the themes property, keep in mind that if there are less than 10 emojis in any array, the app it's going to crash.
 
 - example:
 `controller.themes["Winter"]?.append("😇")`
 
 */
/*:
 
 - note:
 Only the following themes exist in the dictionary: `"Winter", "Animals", "Custom"`.
 
 */


